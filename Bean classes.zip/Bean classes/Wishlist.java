package com.cg.database.beans;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

public class Wishlist {
	@Id
	@SequenceGenerator(name = "wish_id", sequenceName = "wish_id", initialValue = 50000, allocationSize = 1)
	@GeneratedValue(generator = "wish_id")
	private int wishId;
	private int customerId;
	private int productId;

	public Wishlist() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Wishlist(int wishId, int customerId, int productId) {
		super();
		this.wishId = wishId;
		this.customerId = customerId;
		this.productId = productId;
	}

	public int getWishId() {
		return wishId;
	}

	public void setWishId(int wishId) {
		this.wishId = wishId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		return "Wishlist [wishId=" + wishId + ", customerId=" + customerId + ", productId=" + productId + "]";
	}

}
