package com.cg.rating.dao;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.rating.bean.ProductFeedback;

public interface FeedbackDao extends JpaRepository<ProductFeedback, Integer>  {
	
	@Query("from ProductFeedback where productId=:productId")
	List<ProductFeedback> findProductById(@Param("productId") Integer productId);

}
