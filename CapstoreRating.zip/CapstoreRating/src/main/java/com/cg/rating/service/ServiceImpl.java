package com.cg.rating.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.rating.bean.ProductFeedback;
import com.cg.rating.dao.FeedbackDao;

@Service
public class ServiceImpl implements ServiceInterface {

	@Autowired
	FeedbackDao feedbackDao;

	@Override
	public String addRating(Integer productId, Integer rating) {
		ProductFeedback feedback = new ProductFeedback();
		feedback.setProductId(productId);
		feedback.setRating(rating);
		feedbackDao.save(feedback);
		return +feedback.getProductFeedbackId() + " " + feedback.getProductId() + " " + feedback.getRating();

	}

	@Override
	public double getAverageRating(Integer productId) {
		List<ProductFeedback> feedbacks = feedbackDao.findProductById(productId);
		int avg = 0, sum = 0;
		for (ProductFeedback productFeedback : feedbacks) {
			sum = sum + productFeedback.getRating();
		}

		return (double)sum / feedbacks.size();
	}

}
