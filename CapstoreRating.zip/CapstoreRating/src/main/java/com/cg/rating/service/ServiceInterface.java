package com.cg.rating.service;

public interface ServiceInterface {
	public String addRating( Integer productId, Integer rating);
	
	public double getAverageRating(Integer productId);
}
