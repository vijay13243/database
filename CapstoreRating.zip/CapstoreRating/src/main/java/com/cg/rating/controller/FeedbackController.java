package com.cg.rating.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.rating.service.ServiceInterface;

@RestController
public class FeedbackController {
	@Autowired
	ServiceInterface serviceInterface;
	
	@PostMapping("/{productId}/{rating}")
	public String addRating( @PathVariable Integer productId,@PathVariable Integer rating) {
		return serviceInterface.addRating(productId, rating);
	}
	
	  @GetMapping("/average/{productId}")
	  public double getAverageRating(@PathVariable Integer productId) {
		  return serviceInterface.getAverageRating(productId); }
	 
}
